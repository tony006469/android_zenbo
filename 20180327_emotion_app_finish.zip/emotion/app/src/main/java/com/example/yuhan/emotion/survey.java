package com.example.yuhan.emotion;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

/**
 * Created by YuHan on 2018/1/15.
 */

public class survey extends AppCompatActivity {

    TextView score;
    int[] count = {-1, -1, -1, -1, -1};
    int sum = 0;
    RadioGroup item1, item2, item3, item4, item5;
    RadioButton mRadioButton1, mRadioButton2, mRadioButton3, mRadioButton4, mRadioButton5,
            mRadioButton6, mRadioButton7, mRadioButton8, mRadioButton9, mRadioButton10,
            mRadioButton11, mRadioButton12, mRadioButton13, mRadioButton14, mRadioButton15,
            mRadioButton16, mRadioButton17, mRadioButton18, mRadioButton19, mRadioButton20,
            mRadioButton21, mRadioButton22, mRadioButton23, mRadioButton24, mRadioButton25;
    Button sendbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.survey);

        mRadioButton1 = (RadioButton) findViewById(R.id.radioButton1);
        mRadioButton2 = (RadioButton) findViewById(R.id.radioButton2);
        mRadioButton3 = (RadioButton) findViewById(R.id.radioButton3);
        mRadioButton4 = (RadioButton) findViewById(R.id.radioButton4);
        mRadioButton5 = (RadioButton) findViewById(R.id.radioButton5);
        mRadioButton6 = (RadioButton) findViewById(R.id.radioButton6);
        mRadioButton7 = (RadioButton) findViewById(R.id.radioButton7);
        mRadioButton8 = (RadioButton) findViewById(R.id.radioButton8);
        mRadioButton9 = (RadioButton) findViewById(R.id.radioButton9);
        mRadioButton10 = (RadioButton) findViewById(R.id.radioButton10);
        mRadioButton11 = (RadioButton) findViewById(R.id.radioButton11);
        mRadioButton12 = (RadioButton) findViewById(R.id.radioButton12);
        mRadioButton13 = (RadioButton) findViewById(R.id.radioButton13);
        mRadioButton14 = (RadioButton) findViewById(R.id.radioButton14);
        mRadioButton15 = (RadioButton) findViewById(R.id.radioButton15);
        mRadioButton16 = (RadioButton) findViewById(R.id.radioButton16);
        mRadioButton17 = (RadioButton) findViewById(R.id.radioButton17);
        mRadioButton18 = (RadioButton) findViewById(R.id.radioButton18);
        mRadioButton19 = (RadioButton) findViewById(R.id.radioButton19);
        mRadioButton20 = (RadioButton) findViewById(R.id.radioButton20);
        mRadioButton21 = (RadioButton) findViewById(R.id.radioButton21);
        mRadioButton22 = (RadioButton) findViewById(R.id.radioButton22);
        mRadioButton23 = (RadioButton) findViewById(R.id.radioButton23);
        mRadioButton24 = (RadioButton) findViewById(R.id.radioButton24);
        mRadioButton25 = (RadioButton) findViewById(R.id.radioButton25);

        item1 = (RadioGroup) findViewById(R.id.item1);
        item2 = (RadioGroup) findViewById(R.id.item2);
        item3 = (RadioGroup) findViewById(R.id.item3);
        item4 = (RadioGroup) findViewById(R.id.item4);
        item5 = (RadioGroup) findViewById(R.id.item5);

        //設定單選選項監聽器
        item1.setOnCheckedChangeListener(radGrpRegionOnCheckedChange);
        item2.setOnCheckedChangeListener(radGrpRegionOnCheckedChange);
        item3.setOnCheckedChangeListener(radGrpRegionOnCheckedChange);
        item4.setOnCheckedChangeListener(radGrpRegionOnCheckedChange);
        item5.setOnCheckedChangeListener(radGrpRegionOnCheckedChange);

        score = (TextView) findViewById(R.id.textView_score);
        sendbutton = (Button) findViewById(R.id.sendbutton);
        sendbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Calendar c = Calendar.getInstance();
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
                String str = simpleDateFormat.format(c.getTime());

                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference myRef = database.getReference("SURVEY").child(zenboSerial).child(str);

                HashMap<String, Object> result = new HashMap<>();
                result.put("score1", count[0]);
                result.put("score2", count[1]);
                result.put("score3", count[2]);
                result.put("score4", count[3]);
                result.put("score5", count[4]);
                result.put("Total", sum);
                myRef.updateChildren(result);

                showAletDialog();

            }
        });
    }

    private String zenboSerial = Build.SERIAL;


    private void ShowScore() {
        //確認是否都有作答
        sum = 0;
        for (int s = 0; s < count.length; s++) {
            if (count[s] >= 0) {
                sum += count[s];
            }
        }
        score.setText("得分：" + String.valueOf(sum));
    }


    private void showAletDialog() {

        for (int i = 0; i < count.length; i++) {
            if (count[i] < 0) {
                //產生視窗物件
                new AlertDialog.Builder(this)
                        .setTitle("問卷未完成")//設定視窗標題
                        .setIcon(R.drawable.survey)//設定對話視窗圖示
                        .setMessage("問卷尚有題目未填寫，請檢查是否完成")//設定顯示的文字
                        .setPositiveButton("回到問卷", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        })//設定結束的子視窗
                        .show();//呈現對話視窗
                return;
            }
        }

        if (sum > 15) {
            //產生視窗物件
            new AlertDialog.Builder(this)
                    .setTitle("建議")//設定視窗標題
                    .setIcon(R.drawable.darkred)//設定對話視窗圖示
                    .setMessage("重度情緒困擾，建議咨詢精神科醫師接受進一步評估。")//設定顯示的文字
                    .setPositiveButton("確認資訊", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }
                    })//設定結束的子視窗
                    .setNegativeButton("幫我預約精神科醫生",new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //打電話;

                            Intent it = new Intent();
                            it.setAction(Intent.ACTION_VIEW);
                            it.setData(Uri.parse("tel:000"));
                            startActivity(it);
                            finish();
                        }
                    })//設定結束的子視窗
                    .show();//呈現對話視窗
        } else if (sum >= 0 && sum <= 5) {
            //產生視窗物件
            new AlertDialog.Builder(this)
                    .setTitle("建議")//設定視窗標題
                    .setIcon(R.drawable.green)//設定對話視窗圖示
                    .setMessage("身心適應狀態良好。")//設定顯示的文字
                    .setPositiveButton("確認資訊", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }
                    })//設定結束的子視窗
                    .show();//呈現對話視窗
        } else if (sum >= 6 && sum <= 9) {
            //產生視窗物件
            new AlertDialog.Builder(this)
                    .setTitle("建議")//設定視窗標題
                    .setIcon(R.drawable.yellow)//設定對話視窗圖示
                    .setMessage("輕度情緒困擾，建議尋求紓壓管道或接受心理專業諮詢。")//設定顯示的文字
                    .setPositiveButton("確認資訊", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }
                    })//設定結束的子視窗
                    .show();//呈現對話視窗
        } else if (sum >= 10 && sum <= 14) {
            //產生視窗物件
            new AlertDialog.Builder(this)
                    .setTitle("建議")//設定視窗標題
                    .setIcon(R.drawable.red)//設定對話視窗圖示
                    .setMessage("中度情緒困擾，建議咨詢精神科醫師接受進一步評估。")//設定顯示的文字
                    .setPositiveButton("確認資訊", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }
                    })//設定結束的子視窗
                    .show();//呈現對話視窗
        }
    }

    private RadioGroup.OnCheckedChangeListener radGrpRegionOnCheckedChange =
            new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    switch (checkedId) {
                        case R.id.radioButton1:
                            count[0] = 0;
                            ShowScore();
                            break;

                        case R.id.radioButton2:
                            count[0] = 1;
                            ShowScore();
                            break;

                        case R.id.radioButton3:
                            count[0] = 2;
                            ShowScore();
                            break;

                        case R.id.radioButton4:
                            count[0] = 3;
                            ShowScore();
                            break;

                        case R.id.radioButton5:
                            count[0] = 4;
                            ShowScore();
                            break;

                        case R.id.radioButton6:
                            count[1] = 0;
                            ShowScore();
                            break;

                        case R.id.radioButton7:
                            count[1] = 1;
                            ShowScore();
                            break;

                        case R.id.radioButton8:
                            count[1] = 2;
                            ShowScore();
                            break;

                        case R.id.radioButton9:
                            count[1] = 3;
                            ShowScore();
                            break;

                        case R.id.radioButton10:
                            count[1] = 4;
                            ShowScore();
                            break;

                        case R.id.radioButton11:
                            count[2] = 0;
                            ShowScore();
                            break;

                        case R.id.radioButton12:
                            count[2] = 1;
                            ShowScore();
                            break;

                        case R.id.radioButton13:
                            count[2] = 2;
                            ShowScore();
                            break;

                        case R.id.radioButton14:
                            count[2] = 3;
                            ShowScore();
                            break;

                        case R.id.radioButton15:
                            count[2] = 4;
                            ShowScore();
                            break;

                        case R.id.radioButton16:
                            count[3] = 0;
                            ShowScore();
                            break;

                        case R.id.radioButton17:
                            count[3] = 1;
                            ShowScore();
                            break;

                        case R.id.radioButton18:
                            count[3] = 2;
                            ShowScore();
                            break;

                        case R.id.radioButton19:
                            count[3] = 3;
                            ShowScore();
                            break;

                        case R.id.radioButton20:
                            count[3] = 4;
                            ShowScore();
                            break;

                        case R.id.radioButton21:
                            count[4] = 0;
                            ShowScore();
                            break;

                        case R.id.radioButton22:
                            count[4] = 1;
                            ShowScore();
                            break;

                        case R.id.radioButton23:
                            count[4] = 2;
                            ShowScore();
                            break;

                        case R.id.radioButton24:
                            count[4] = 3;
                            ShowScore();
                            break;

                        case R.id.radioButton25:
                            count[4] = 4;
                            ShowScore();
                            break;
                    }
                }
            };


}





