package com.example.yuhan.emotion;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

import cz.msebera.android.httpclient.HttpEntity;
import cz.msebera.android.httpclient.HttpResponse;
import cz.msebera.android.httpclient.client.HttpClient;
import cz.msebera.android.httpclient.client.methods.HttpPost;
import cz.msebera.android.httpclient.client.utils.URIBuilder;
import cz.msebera.android.httpclient.entity.ByteArrayEntity;
import cz.msebera.android.httpclient.impl.client.HttpClients;
import cz.msebera.android.httpclient.util.EntityUtils;

/**
 * Created by YuHan on 2018/1/15.
 */

public class picture extends AppCompatActivity {

    ImageView imv;
    Uri imgUri;
    TextView resultText;

    protected void onCreate(Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.takeapicture);
        imv = (ImageView) findViewById(R.id.imageView);
        resultText = (TextView) findViewById(R.id.resultText);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_NOSENSOR);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
    }


    public void onGet(View v) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 200);
        } else {
            savePhoto();
        }
    }

    // when the "GET EMOTION" Button is clicked this function is executed

    public void onResult(View view) {


        GetEmotionCall emotionCall = new GetEmotionCall(imv);
        emotionCall.execute();

        //run the GetEmotionCall class in the background

    }

    private String zenboSerial = Build.SERIAL;

    public void onPick(View v) {
        Intent it = new Intent(Intent.ACTION_GET_CONTENT);
        it.setType("image/*");
        startActivityForResult(it, 101);
    }

    // protected void onActivityResult(int requestCode, int resultCode, Intent data){
    //     super.onActivityResult(requestCode, resultCode, data);
    //     if(resultCode == Activity.RESULT_OK && requestCode == 100){
    //        Bundle extras = data.getExtras();
    //         Bitmap bmp = (Bitmap) extras.get("data");
    //         ImageView imv = (ImageView) findViewById(R.id.imageView);
    //         imv.setImageBitmap(bmp);
    //     }
    //     else {
    //         Toast.makeText(this,"沒有拍到照片",Toast.LENGTH_LONG).show();
    //     }
    // }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 200) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                savePhoto();
            } else {
                Toast.makeText(this, "程式需要寫入權限才能運作", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void savePhoto() {
        imgUri = getContentResolver().insert(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, new ContentValues());
        Intent it = new Intent("android.media.action.IMAGE_CAPTURE");
        it.putExtra(MediaStore.EXTRA_OUTPUT, imgUri);
        startActivityForResult(it, 100);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            switch (requestCode) {
                case 100:
                    Intent it = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, imgUri);
                    sendBroadcast(it);
                    break;
                case 101:
                    imgUri = data.getData();
                    break;
            }
            showImg();
        } else {
            Toast.makeText(this, "沒有拍到照片", Toast.LENGTH_LONG).show();
        }

    }

    void showImg() {
        int iw, ih, vw, vh;
        boolean needRotate;
        BitmapFactory.Options option = new BitmapFactory.Options();
        option.inJustDecodeBounds = true;

        try {
            BitmapFactory.decodeStream(
                    getContentResolver().openInputStream(imgUri), null, option);
        } catch (IOException e) {
            Toast.makeText(this, "讀取照片資訊時發生錯誤", Toast.LENGTH_LONG).show();
            return;
        }
        iw = option.outWidth;
        ih = option.outHeight;
        vw = imv.getWidth();
        vh = imv.getHeight();

        int scaleFactor;
        if (iw < ih) {
            needRotate = false;
            scaleFactor = Math.min(iw / vw, ih / vh);
        } else {
            needRotate = true;
            scaleFactor = Math.min(ih / vw, iw / vh);
        }

        option.inJustDecodeBounds = false;
        option.inSampleSize = scaleFactor;

        Bitmap bmp = null;
        try {
            bmp = BitmapFactory.decodeStream(
                    getContentResolver().openInputStream(imgUri), null, option
            );
        } catch (IOException e) {
            Toast.makeText(this, "無法取得照片", Toast.LENGTH_LONG).show();
        }

        if (needRotate) {
            Matrix matrix = new Matrix();
            matrix.postRotate(90);
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), matrix, true);
        }

        imv.setImageBitmap(bmp);
    }


    // convert image to base 64 so that we can send the image to Emotion API
    public byte[] toBase64(ImageView imgPreview) {
        Bitmap bm = ((BitmapDrawable) imgPreview.getDrawable()).getBitmap();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        return baos.toByteArray();
    }


    // asynchronous class which makes the API call in the background
    private class GetEmotionCall extends AsyncTask<Void, Void, String> {

        private final ImageView img;

        GetEmotionCall(ImageView img) {
            this.img = img;
        }


        // this function is called before the API call is made
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            resultText.setText("Getting results...");
        }


        // Replace the subscriptionKey string value with your valid subscription key.
        public static final String subscriptionKey = "1994ee8842454b8dac18ef9f84954d49";

        // Replace or verify the region.
        //
        // You must use the same region in your REST API call as you used to obtain your subscription keys.
        // For example, if you obtained your subscription keys from the westus region, replace
        // "westcentralus" in the URI below with "westus".

        // NOTE: Free trial subscription keys are generated in the westcentralus region, so if you are using
        // a free trial subscription key, you should not need to change this region.
        public static final String uriBase = "https://westcentralus.api.cognitive.microsoft.com/face/v1.0/detect";


        // this function is called when the API call is made
        @Override
        protected String doInBackground(Void... params) {

            HttpClient httpclient = HttpClients.createDefault();
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);


            try {
                URIBuilder builder = new URIBuilder(uriBase);

                // Request parameters. All of them are optional.
                builder.setParameter("returnFaceId", "true");
                builder.setParameter("returnFaceLandmarks", "false");
                builder.setParameter("returnFaceAttributes", "age,gender,emotion");

                // Prepare the URI for the REST API call.
                URI uri = builder.build();
                HttpPost request = new HttpPost(uri);


                // Request headers.
                request.setHeader("Content-Type", "application/octet-stream");
                request.setHeader("Ocp-Apim-Subscription-Key", subscriptionKey);


                // Request body.The parameter of setEntity converts the image to base64
                request.setEntity(new ByteArrayEntity(toBase64(img)));

                // getting a response and assigning it to the string res
                HttpResponse response = httpclient.execute(request);
                HttpEntity entity = response.getEntity();
                String res = EntityUtils.toString(entity);

                return res;

            } catch (Exception e) {
            }
            return "null";
        }

        // this function is called when we get a result from the API call
        @Override
        protected void onPostExecute(String result) {

            try {
                // convert the string to JSONArray
                JSONArray jsonArray = new JSONArray(result);

                // get the scores object from the results
                for (int i = 0; i < jsonArray.length(); i++) {

                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    JSONObject jsonObject1 = new JSONObject(jsonObject.getString("faceRectangle"));
                    String top = jsonObject1.getString("top");
                    String left = jsonObject1.getString("left");
                    String width = jsonObject1.getString("width");
                    String height = jsonObject1.getString("height");

                    JSONObject jsonObject2 = new JSONObject(jsonObject.getString("faceAttributes"));
                    JSONObject jsonObject3 = new JSONObject(jsonObject2.getString("emotion"));

                    String[] emotions = {"anger", "contempt", "disgust", "fear", "happiness", "neutral", "sadness", "surprise"};

                    int position = -1;
                    double position_count = -1;

                    for (int j = 0; j < emotions.length; j++) {
                        double count = Double.parseDouble(jsonObject3.getString(emotions[j]));
                        if (count > position_count) {
                            position = j;
                            position_count = count;
                        }
                    }

                    String emotion = emotions[position];

                    resultText.setText(emotion + " " + String.valueOf(position_count));

                    Calendar c = Calendar.getInstance();
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
                    String str = simpleDateFormat.format(c.getTime());

                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                    DatabaseReference myRef = database.getReference("EMOTION").child(zenboSerial).child(str);

                    //放入所產生的情緒
                    HashMap<String, Object> results = new HashMap<>();
                    results.put("emotion", emotion);
                    myRef.updateChildren(results);

                    Dialog(emotion);
                }


            } catch (Exception e) {
                resultText.setText("No emotion detected. Try again later");
            }

        }
    }

    public void Dialog(String emotion) {
        String title = "", message = "";
        if (emotion.equals("happiness") || emotion.equals("surprise") || emotion.equals("neutral")) {
            title = "現在心情很好";
            message = "你今天心情很好耶！要不要聽聽開心的音樂";

        } else {
            title = "現在心情不太好";
            message = "你今天心情不好嗎？要不要聽聽舒壓的音樂，可以開心點喔！";
        }

        new AlertDialog.Builder(this)
                .setTitle(title)//設定視窗標題
                .setIcon(R.drawable.button_music)//設定對話視窗圖示
                .setMessage(message+"\n"+emotion)//設定顯示的文字
                .setPositiveButton("好喔！", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(picture.this, music.class);
                        startActivity(intent);
                        finish();
                    }
                })//設定結束的子視窗
                .setNegativeButton("我不想！", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                })//設定結束的子視窗
                .show();//呈現對話視窗

    }


}
