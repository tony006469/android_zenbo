package com.example.yuhan.emotion;

import org.json.JSONObject;

/**
 * Created by YuHan on 2018/4/10.
 */

public interface RobotUtilCallback {
    void onEventUserUtterance(JSONObject _jsonObject);
}
