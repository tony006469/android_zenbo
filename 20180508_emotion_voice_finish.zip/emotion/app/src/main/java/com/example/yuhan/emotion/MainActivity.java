package com.example.yuhan.emotion;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;

import com.asus.robotframework.API.RobotFace;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity implements RobotUtilCallback {

    @Override
    protected void onResume() {
        super.onResume();
        RobotUtil.getInstance().Resume();
        RobotUtil.getInstance().defaultValue(this, this);
        isRun = false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RobotUtil.getInstance().defaultValue(this, this);

        ImageButton camera = (ImageButton) findViewById(R.id.imageButton_camera);
        ImageButton survey = (ImageButton) findViewById(R.id.imageButton_survey);
        ImageButton music = (ImageButton) findViewById(R.id.imageButton_musicplayer);
        ImageButton air = (ImageButton) findViewById(R.id.imageButton_air);
        camera.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(MainActivity.this, picture.class);
                startActivity(intent);
                //finish();
            }
        });

        survey.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(MainActivity.this, survey.class);
                startActivity(intent);
                //finish();
            }
        });

        music.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(MainActivity.this, music.class);
                startActivity(intent);
                //finish();
            }
        });

        air.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Intent intent = new Intent(MainActivity.this, air.class);
                startActivity(intent);
                //finish();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    boolean isRun = false;

    @Override
    public void onEventUserUtterance(JSONObject _jsonObject) {
        RobotUtil.getInstance().robotAPI.robot.setExpression(RobotFace.HIDEFACE);
        try {
            JSONObject jsonObject = _jsonObject.getJSONObject("event_user_utterance");
            JSONArray jA = new JSONArray(jsonObject.getString("user_utterance"));
            JSONArray jsonArray = null;
            String string = "";
            try {
                jsonArray = jA.getJSONObject(0).getJSONArray("result");
            } catch (Exception e) {
                e.printStackTrace();
                string = jA.getJSONObject(0).getString("result");
            }

            if (jsonArray != null) {
                for (int i = 0; i < jsonArray.length(); i++) {
                    Log.d("MainActivity", "jsonArray1 " + i + " - " + jsonArray.getString(i));
                    String _str = jsonArray.getString(i);

                    if (_str.equals("今天心情") || _str.equals("我的心情") || _str.equals("開心") || _str.equals("難過")) {
                        if (!isRun) {
                            isRun = true;
                            RobotUtil.getInstance().robotAPI.robot.speakAndListen("我來幫你看看你今天心情如何！請說幫我拍照或是選擇相片", 2f);
                            Intent intent = new Intent(MainActivity.this, picture.class);
                            startActivity(intent);
                        }
                        break;
                    } else if (_str.equals("聽個音樂") || _str.equals("開心的音樂") || _str.equals("不開心的音樂")) {
                        if (!isRun) {
                            isRun = true;
                            RobotUtil.getInstance().robotAPI.robot.speakAndListen("來聽聽音樂，放鬆一下心情！請選擇音樂或是選擇影片，還是你要開啟youtube或是KKBOX", 2f);
                            Intent intent = new Intent(MainActivity.this, music.class);
                            startActivity(intent);
                        }
                        break;
                    } else if (_str.equals("我要填問卷") || _str.equals("我要寫問卷") || _str.equals("寫問卷") || _str.equals("填問卷") || _str.equals("問卷")) {
                        if (!isRun) {
                            isRun = true;
                            Intent intent = new Intent(MainActivity.this, survey.class);
                            startActivity(intent);
                            RobotUtil.getInstance().robotAPI.robot.speakAndListen("開始填寫問卷，請說第一題", 2f);
                        }
                            break;
                    } else if (_str.equals("空氣品質") || _str.equals("AQI") || _str.equals("今天空氣")) {
                        if (!isRun) {
                            isRun = true;
                            Intent intent = new Intent(MainActivity.this, air.class);
                            startActivity(intent);
                            RobotUtil.getInstance().robotAPI.robot.speakAndListen("今天空氣品質", 2f);
                        }
                            break;
                    }
                }
            } else {
                String _str = string;
                if (_str.equals("今天心情") || _str.equals("我的心情") || _str.equals("開心") || _str.equals("難過")) {
                    if (!isRun) {
                        isRun = true;
                        RobotUtil.getInstance().robotAPI.robot.speakAndListen("我來幫你看看你今天心情如何！請說幫我拍照或是選擇相片", 2f);
                        Intent intent = new Intent(MainActivity.this, picture.class);
                        startActivity(intent);
                    }
                } else if (_str.equals("聽個音樂") || _str.equals("開心的音樂") || _str.equals("不開心的音樂")) {
                    if (!isRun) {
                        isRun = true;
                        RobotUtil.getInstance().robotAPI.robot.speakAndListen("來聽聽音樂，放鬆一下心情！請選擇音樂或是選擇影片，還是你要開啟youtube或是KKBOX", 2f);
                        Intent intent = new Intent(MainActivity.this, music.class);
                        startActivity(intent);
                    }
                } else if (_str.equals("我要填問卷") || _str.equals("我要寫問卷") || _str.equals("寫問卷") || _str.equals("填問卷") || _str.equals("問卷")) {
                    if (!isRun) {
                        isRun = true;
                        Intent intent = new Intent(MainActivity.this, survey.class);
                        startActivity(intent);
                        RobotUtil.getInstance().robotAPI.robot.speakAndListen("開始填寫問卷，請說第一題", 2f);
                    }
                } else if (_str.equals("空氣品質") || _str.equals("AQI") || _str.equals("今天空氣")) {
                    if (!isRun) {
                        isRun = true;
                        Intent intent = new Intent(MainActivity.this, air.class);
                        RobotUtil.getInstance().robotAPI.robot.speakAndListen("今天空氣品質", 2f);
                        startActivity(intent);
                    }
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
            Log.d("MainActivity", "JSONException - " + e.toString());
        }
    }

}
