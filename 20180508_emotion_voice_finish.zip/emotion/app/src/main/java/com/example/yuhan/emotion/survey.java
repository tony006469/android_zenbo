package com.example.yuhan.emotion;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.asus.robotframework.API.RobotFace;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

/**
 * Created by YuHan on 2018/1/15.
 */

public class survey extends Activity implements RobotUtilCallback {

    TextView score;
    int[] count = {-1, -1, -1, -1, -1};
    int sum = 0;
    RadioGroup item1, item2, item3, item4, item5;
    RadioButton mRadioButton1, mRadioButton2, mRadioButton3, mRadioButton4, mRadioButton5,
            mRadioButton6, mRadioButton7, mRadioButton8, mRadioButton9, mRadioButton10,
            mRadioButton11, mRadioButton12, mRadioButton13, mRadioButton14, mRadioButton15,
            mRadioButton16, mRadioButton17, mRadioButton18, mRadioButton19, mRadioButton20,
            mRadioButton21, mRadioButton22, mRadioButton23, mRadioButton24, mRadioButton25;
    Button sendbutton;

    //region robot
//    public survey() {
//        super(robotCallback, robotListenCallback);
//    }
//
//    public static RobotCallback robotCallback = new RobotCallback() {
//        @Override
//        public void onResult(int cmd, int serial, RobotErrorCode err_code, Bundle result) {
//            super.onResult(cmd, serial, err_code, result);
//        }
//
//        @Override
//        public void onStateChange(int cmd, int serial, RobotErrorCode err_code, RobotCmdState state) {
//            super.onStateChange(cmd, serial, err_code, state);
//        }
//    };
//
//    public static RobotCallback.Listen robotListenCallback = new RobotCallback.Listen() {
//
//        @Override
//        public void onFinishRegister() {
//
//        }
//
//        @Override
//        public void onVoiceDetect(JSONObject jsonObject) {
//
//        }
//
//        @Override
//        public void onSpeakComplete(String s, String s1) {
//
//        }
//
//        @Override
//        public void onEventUserUtterance(JSONObject _jsonObject) {
//            Log.d("Survey", "onEventUserUtterance - " + _jsonObject.toString());
//            survey survey = new survey();
//            //int iAnswer = 0;
//            //int iQuestion = 0;
//
//            try {
//                JSONObject jsonObject = _jsonObject.getJSONObject("event_user_utterance");
//                JSONArray jA = new JSONArray(jsonObject.getString("user_utterance"));
//                JSONArray jsonArray = null;
//                String string = "";
//                try {
//                    jsonArray = jA.getJSONObject(0).getJSONArray("result");
//                } catch (Exception e) {
//                    e.printStackTrace();
//                    string = jA.getJSONObject(0).getString("result");
//                }
//
//                if (jsonArray != null) {
//                    for (int i = 0; i < jsonArray.length(); i++) {
//                        Log.d("Survey", "jsonArray1 " + i + " - " + jsonArray.getString(i));
//                        String _str = jsonArray.getString(i);
//
//                        if (_str.equals("沒有") || _str.equals("完全沒有") || _str.equals("0分")) {
//                            survey.speakResult(false, 1);
//                            //iAnswer = 1;
//                            break;
//                        } else if (_str.equals("輕微") || _str.equals("1分")) {
//                            survey.speakResult(false, 2);
//                            //iAnswer = 2;
//                            break;
//                        } else if (_str.equals("中等") || _str.equals("中等程度") || _str.equals("2分")) {
//                            survey.speakResult(false, 3);
//                            //iAnswer = 3;
//                            break;
//                        } else if (_str.equals("厲害") || _str.equals("3分")) {
//                            survey.speakResult(false, 4);
//                            //iAnswer = 4;
//                            break;
//                        } else if (_str.equals("非常") || _str.equals("非常厲害") || _str.equals("4分")) {
//                            survey.speakResult(false, 5);
//                            //iAnswer = 5;
//                            break;
//                        } else if (_str.equals("Question one") || _str.equals("第一題") || _str.equals("一") || _str.equals("1")) {
//                            survey.speakResult(true, 1);
//                            survey.robotAPI.robot.speakAndListen("感覺緊張不安", 5f);
//                            //iQuestion =1;
//                            break;
//                        } else if (_str.equals("Question two") || _str.equals("第二題") || _str.equals("二") || _str.equals("2")) {
//                            survey.speakResult(true, 2);
//                            survey.robotAPI.robot.speakAndListen("覺得容易苦惱或動怒", 5f);
//                            //iQuestion =2;
//                            break;
//                        } else if (_str.equals("Question three") || _str.equals("第三題") || _str.equals("三") || _str.equals("3")) {
//                            survey.speakResult(true, 3);
//                            survey.robotAPI.robot.speakAndListen("感覺憂鬱、心情低弱", 5f);
//                            //iQuestion =3;
//                            break;
//                        } else if (_str.equals("Question three") || _str.equals("第四題") || _str.equals("四") || _str.equals("4")) {
//                            survey.speakResult(true, 4);
//                            survey.robotAPI.robot.speakAndListen("覺得比不上別人", 5f);
//                            //iQuestion =4;
//                            break;
//                        } else if (_str.equals("送出問卷") || _str.equals("送出")) {
//                            survey.showAletDialog();
//                            break;
//                        }
//                    }
//                } else {
//                    String _str = string;
//                    if (_str.equals("沒有") || _str.equals("完全沒有") || _str.equals("0分")) {
//                        survey.speakResult(false, 1);
//                        //iAnswer = 1;
//                    } else if (_str.equals("輕微") || _str.equals("1分")) {
//                        survey.speakResult(false, 2);
//                        //iAnswer = 2;
//                    } else if (_str.equals("中等") || _str.equals("中等程度") || _str.equals("2分")) {
//                        survey.speakResult(false, 3);
//                        //iAnswer = 3;
//                    } else if (_str.equals("厲害") || _str.equals("3分")) {
//                        survey.speakResult(false, 4);
//                        //iAnswer = 4;
//                    } else if (_str.equals("非常") || _str.equals("非常厲害") || _str.equals("4分")) {
//                        survey.speakResult(false, 5);
//                        //iAnswer = 5;
//                    } else if (_str.equals("Question one") || _str.equals("第一題") || _str.equals("一") || _str.equals("1")) {
//                        survey.speakResult(true, 1);
//                        survey.robotAPI.robot.speakAndListen("感覺緊張不安", 5f);
//                        //iQuestion =1;
//                    } else if (_str.equals("Question two") || _str.equals("第二題") || _str.equals("二") || _str.equals("2")) {
//                        survey.speakResult(true, 2);
//                        survey.robotAPI.robot.speakAndListen("覺得容易苦惱或動怒", 5f);
//                        //iQuestion =2;
//                    } else if (_str.equals("Question three") || _str.equals("第三題") || _str.equals("三") || _str.equals("3")) {
//                        survey.speakResult(true, 3);
//                        survey.robotAPI.robot.speakAndListen("感覺憂鬱、心情低弱", 5f);
//                        //iQuestion =3;
//                    } else if (_str.equals("Question three") || _str.equals("第四題") || _str.equals("四") || _str.equals("4")) {
//                        survey.speakResult(true, 4);
//                        survey.robotAPI.robot.speakAndListen("覺得比不上別人", 5f);
//                        //iQuestion =4;
//                    } else if (_str.equals("送出問卷") || _str.equals("送出")) {
//                        survey.showAletDialog();
//                    }
//                }
//
//            } catch (JSONException e) {
//                e.printStackTrace();
//                Log.d("Survey", "JSONException - " + e.toString());
//            }
//
//        }
//
//        @Override
//        public void onResult(JSONObject jsonObject) {
//
//        }
//
//        @Override
//        public void onRetry(JSONObject jsonObject) {
//
//        }
//    };
    //endregion

    @Override
    protected void onResume() {
        super.onResume();
//        robotAPI.robot.speakAndListen("嗨！開始填問卷囉！請說第一題", 5f);
//        robotAPI.robot.setExpression(RobotFace.HIDEFACE);
        isRun = false;
        RobotUtil.getInstance().Resume();
        RobotUtil.getInstance().defaultValue(this, this);
    }


    public void speakResult(boolean isQuestion, int value) {
        if (isQuestion) {
            iQuestion = value;
        } else {
            //Answer
            if (iQuestion == 1 && value == 1) {
                mRadioButton1.setChecked(true);
            } else if (iQuestion == 1 && value == 2) {
                mRadioButton2.setChecked(true);
            } else if (iQuestion == 1 && value == 3) {
                mRadioButton3.setChecked(true);
            } else if (iQuestion == 1 && value == 4) {
                mRadioButton4.setChecked(true);
            } else if (iQuestion == 1 && value == 5) {
                mRadioButton5.setChecked(true);
            } else if (iQuestion == 2 && value == 1) {
                mRadioButton6.setChecked(true);
            } else if (iQuestion == 2 && value == 2) {
                mRadioButton7.setChecked(true);
            } else if (iQuestion == 2 && value == 3) {
                mRadioButton8.setChecked(true);
            } else if (iQuestion == 2 && value == 4) {
                mRadioButton9.setChecked(true);
            } else if (iQuestion == 2 && value == 5) {
                mRadioButton10.setChecked(true);
            } else if (iQuestion == 3 && value == 1) {
                mRadioButton11.setChecked(true);
            } else if (iQuestion == 3 && value == 2) {
                mRadioButton12.setChecked(true);
            } else if (iQuestion == 3 && value == 3) {
                mRadioButton13.setChecked(true);
            } else if (iQuestion == 3 && value == 4) {
                mRadioButton14.setChecked(true);
            } else if (iQuestion == 3 && value == 5) {
                mRadioButton15.setChecked(true);
            } else if (iQuestion == 4 && value == 1) {
                mRadioButton16.setChecked(true);
            } else if (iQuestion == 4 && value == 2) {
                mRadioButton17.setChecked(true);
            } else if (iQuestion == 4 && value == 3) {
                mRadioButton18.setChecked(true);
            } else if (iQuestion == 4 && value == 4) {
                mRadioButton19.setChecked(true);
            } else if (iQuestion == 4 && value == 5) {
                mRadioButton20.setChecked(true);
            } else if (iQuestion == 5 && value == 1) {
                mRadioButton21.setChecked(true);
            } else if (iQuestion == 5 && value == 2) {
                mRadioButton22.setChecked(true);
            } else if (iQuestion == 5 && value == 3) {
                mRadioButton23.setChecked(true);
            } else if (iQuestion == 5 && value == 4) {
                mRadioButton24.setChecked(true);
            } else if (iQuestion == 5 && value == 5) {
                mRadioButton25.setChecked(true);
            }

        }
    }

    private int iQuestion = -1; //記錄第幾題

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.survey);

        RobotUtil.getInstance().defaultValue(this, this);


        mRadioButton1 = (RadioButton) findViewById(R.id.radioButton1);
        mRadioButton2 = (RadioButton) findViewById(R.id.radioButton2);
        mRadioButton3 = (RadioButton) findViewById(R.id.radioButton3);
        mRadioButton4 = (RadioButton) findViewById(R.id.radioButton4);
        mRadioButton5 = (RadioButton) findViewById(R.id.radioButton5);
        mRadioButton6 = (RadioButton) findViewById(R.id.radioButton6);
        mRadioButton7 = (RadioButton) findViewById(R.id.radioButton7);
        mRadioButton8 = (RadioButton) findViewById(R.id.radioButton8);
        mRadioButton9 = (RadioButton) findViewById(R.id.radioButton9);
        mRadioButton10 = (RadioButton) findViewById(R.id.radioButton10);
        mRadioButton11 = (RadioButton) findViewById(R.id.radioButton11);
        mRadioButton12 = (RadioButton) findViewById(R.id.radioButton12);
        mRadioButton13 = (RadioButton) findViewById(R.id.radioButton13);
        mRadioButton14 = (RadioButton) findViewById(R.id.radioButton14);
        mRadioButton15 = (RadioButton) findViewById(R.id.radioButton15);
        mRadioButton16 = (RadioButton) findViewById(R.id.radioButton16);
        mRadioButton17 = (RadioButton) findViewById(R.id.radioButton17);
        mRadioButton18 = (RadioButton) findViewById(R.id.radioButton18);
        mRadioButton19 = (RadioButton) findViewById(R.id.radioButton19);
        mRadioButton20 = (RadioButton) findViewById(R.id.radioButton20);
        mRadioButton21 = (RadioButton) findViewById(R.id.radioButton21);
        mRadioButton22 = (RadioButton) findViewById(R.id.radioButton22);
        mRadioButton23 = (RadioButton) findViewById(R.id.radioButton23);
        mRadioButton24 = (RadioButton) findViewById(R.id.radioButton24);
        mRadioButton25 = (RadioButton) findViewById(R.id.radioButton25);

        item1 = (RadioGroup) findViewById(R.id.item1);
        item2 = (RadioGroup) findViewById(R.id.item2);
        item3 = (RadioGroup) findViewById(R.id.item3);
        item4 = (RadioGroup) findViewById(R.id.item4);
        item5 = (RadioGroup) findViewById(R.id.item5);

        //設定單選選項監聽器
        item1.setOnCheckedChangeListener(radGrpRegionOnCheckedChange);
        item2.setOnCheckedChangeListener(radGrpRegionOnCheckedChange);
        item3.setOnCheckedChangeListener(radGrpRegionOnCheckedChange);
        item4.setOnCheckedChangeListener(radGrpRegionOnCheckedChange);
        item5.setOnCheckedChangeListener(radGrpRegionOnCheckedChange);

        score = (TextView) findViewById(R.id.textView_score);
        sendbutton = (Button) findViewById(R.id.sendbutton);
        sendbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Calendar c = Calendar.getInstance();
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
                String str = simpleDateFormat.format(c.getTime());

                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference myRef = database.getReference("SURVEY").child(zenboSerial).child(str);

                HashMap<String, Object> result = new HashMap<>();
                result.put("score1", count[0]);
                result.put("score2", count[1]);
                result.put("score3", count[2]);
                result.put("score4", count[3]);
                result.put("score5", count[4]);
                result.put("Total", sum);
                myRef.updateChildren(result);

                showAletDialog();

            }
        });
    }

    private String zenboSerial = Build.SERIAL;


    private void ShowScore() {
        //確認是否都有作答
        sum = 0;
        for (int s = 0; s < count.length; s++) {
            if (count[s] >= 0) {
                sum += count[s];
            }
        }
        score.setText("得分：" + String.valueOf(sum));
    }


    private AlertDialog dialog;
    private boolean isFinish = false;


    private void showDialog(String title, int iconId, String message, String positiveButtonText, final boolean isCheck, boolean isHeave, String negativeButtonText) {
        RobotUtil.getInstance().robotAPI.robot.speak(message);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setIcon(iconId);
        builder.setMessage(message);
        builder.setPositiveButton(positiveButtonText, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (isCheck) {
                    dialog.dismiss();
                } else {
                    finish();
                }
            }
        });
        if (isHeave) {
            RobotUtil.getInstance().robotAPI.robot.speakAndListen("您要預約嗎", 2f);
            builder.setNegativeButton(negativeButtonText, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent it = new Intent();
                    it.setAction(Intent.ACTION_VIEW);
                    it.setData(Uri.parse("tel:000"));
                    startActivity(it);
                    finish();
                }
            });
        }
        dialog = builder.show();
//        dialog.show();
//        isRun = false;
    }

    private void showAletDialog() {

        for (int i = 0; i < count.length; i++) {
            if (count[i] < 0) {
                //產生視窗物件

//                new AlertDialog.Builder(this)
//                        .setTitle("問卷未完成")//設定視窗標題
//                        .setIcon(R.drawable.survey)//設定對話視窗圖示
//                        .setMessage("問卷尚有題目未填寫，請檢查是否完成")//設定顯示的文字
//                        .setPositiveButton("回到問卷", new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialog, int which) {
//                                dialog.dismiss();
//                            }
//                        })//設定結束的子視窗
//                        .show();//呈現對話視窗
//                RobotUtil.getInstance().robotAPI.robot.speak("問卷尚有題目未填寫，請檢查是否完成");
                showDialog("問卷未完成", R.drawable.survey, "問卷尚有題目未填寫，請檢查是否完成", "回到問卷", true, false, null);
                return;
            }
        }
        
        isFinish=true;

        if (sum > 15) {
            //產生視窗物件
//            new AlertDialog.Builder(this)
//                    .setTitle("建議")//設定視窗標題
//                    .setIcon(R.drawable.darkred)//設定對話視窗圖示
//                    .setMessage("重度情緒困擾，建議咨詢精神科醫師接受進一步評估。")//設定顯示的文字
//                    .setPositiveButton("確認資訊", new DialogInterface.OnClickListener() {
//                        @Override
//                        public void onClick(DialogInterface dialog, int which) {
//                            finish();
//                        }
//                    })//設定結束的子視窗
//                    .setNegativeButton("幫我預約精神科醫生", new DialogInterface.OnClickListener() {
//                        @Override
//                        public void onClick(DialogInterface dialog, int which) {
//                            //打電話;
//
//                            Intent it = new Intent();
//                            it.setAction(Intent.ACTION_VIEW);
//                            it.setData(Uri.parse("tel:000"));
//                            startActivity(it);
//                            finish();
//                        }
//                    })//設定結束的子視窗
//                    .show();//呈現對話視窗
            showDialog("建議", R.drawable.darkred, "重度情緒困擾，建議咨詢精神科醫師接受進一步評估。", "確認資訊", false, true, "幫我預約精神科醫生");
        } else if (sum >= 0 && sum <= 5) {
//            //產生視窗物件
//            new AlertDialog.Builder(this)
//                    .setTitle("建議")//設定視窗標題
//                    .setIcon(R.drawable.green)//設定對話視窗圖示
//                    .setMessage("身心適應狀態良好。")//設定顯示的文字
//                    .setPositiveButton("確認資訊", new DialogInterface.OnClickListener() {
//                        @Override
//                        public void onClick(DialogInterface dialog, int which) {
//                            finish();
//                        }
//                    })//設定結束的子視窗
//                    .show();//呈現對話視窗
            showDialog("建議", R.drawable.green, "身心適應狀態良好", "確認資訊", false, false, null);
        } else if (sum >= 6 && sum <= 9) {
//            //產生視窗物件
//            new AlertDialog.Builder(this)
//                    .setTitle("建議")//設定視窗標題
//                    .setIcon(R.drawable.yellow)//設定對話視窗圖示
//                    .setMessage("輕度情緒困擾，建議尋求紓壓管道或接受心理專業諮詢。")//設定顯示的文字
//                    .setPositiveButton("確認資訊", new DialogInterface.OnClickListener() {
//                        @Override
//                        public void onClick(DialogInterface dialog, int which) {
//                            finish();
//                        }
//                    })//設定結束的子視窗
//                    .show();//呈現對話視窗
            showDialog("建議", R.drawable.yellow, "輕度情緒困擾，建議尋求紓壓管道或接受心理專業諮詢。", "確認資訊", false, false, null);
        } else if (sum >= 10 && sum <= 14) {
//            //產生視窗物件
//            new AlertDialog.Builder(this)
//                    .setTitle("建議")//設定視窗標題
//                    .setIcon(red)//設定對話視窗圖示
//                    .setMessage("中度情緒困擾，建議咨詢精神科醫師接受進一步評估。")//設定顯示的文字
//                    .setPositiveButton("確認資訊", new DialogInterface.OnClickListener() {
//                        @Override
//                        public void onClick(DialogInterface dialog, int which) {
//                            finish();
//                        }
//                    })//設定結束的子視窗
//                    .show();//呈現對話視窗
            showDialog("建議", R.drawable.red, "中度情緒困擾，建議咨詢精神科醫師接受進一步評估。", "確認資訊", false, false, null);
        }
    }

    //region radGrpRegionOnCheckedChange
    private RadioGroup.OnCheckedChangeListener radGrpRegionOnCheckedChange =
            new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    switch (checkedId) {
                        case R.id.radioButton1:
                            count[0] = 0;
                            ShowScore();
                            break;

                        case R.id.radioButton2:
                            count[0] = 1;
                            ShowScore();
                            break;

                        case R.id.radioButton3:
                            count[0] = 2;
                            ShowScore();
                            break;

                        case R.id.radioButton4:
                            count[0] = 3;
                            ShowScore();
                            break;

                        case R.id.radioButton5:
                            count[0] = 4;
                            ShowScore();
                            break;

                        case R.id.radioButton6:
                            count[1] = 0;
                            ShowScore();
                            break;

                        case R.id.radioButton7:
                            count[1] = 1;
                            ShowScore();
                            break;

                        case R.id.radioButton8:
                            count[1] = 2;
                            ShowScore();
                            break;

                        case R.id.radioButton9:
                            count[1] = 3;
                            ShowScore();
                            break;

                        case R.id.radioButton10:
                            count[1] = 4;
                            ShowScore();
                            break;

                        case R.id.radioButton11:
                            count[2] = 0;
                            ShowScore();
                            break;

                        case R.id.radioButton12:
                            count[2] = 1;
                            ShowScore();
                            break;

                        case R.id.radioButton13:
                            count[2] = 2;
                            ShowScore();
                            break;

                        case R.id.radioButton14:
                            count[2] = 3;
                            ShowScore();
                            break;

                        case R.id.radioButton15:
                            count[2] = 4;
                            ShowScore();
                            break;

                        case R.id.radioButton16:
                            count[3] = 0;
                            ShowScore();
                            break;

                        case R.id.radioButton17:
                            count[3] = 1;
                            ShowScore();
                            break;

                        case R.id.radioButton18:
                            count[3] = 2;
                            ShowScore();
                            break;

                        case R.id.radioButton19:
                            count[3] = 3;
                            ShowScore();
                            break;

                        case R.id.radioButton20:
                            count[3] = 4;
                            ShowScore();
                            break;

                        case R.id.radioButton21:
                            count[4] = 0;
                            ShowScore();
                            break;

                        case R.id.radioButton22:
                            count[4] = 1;
                            ShowScore();
                            break;

                        case R.id.radioButton23:
                            count[4] = 2;
                            ShowScore();
                            break;

                        case R.id.radioButton24:
                            count[4] = 3;
                            ShowScore();
                            break;

                        case R.id.radioButton25:
                            count[4] = 4;
                            ShowScore();
                            break;
                    }
                }
            };
    //endregion

    boolean isRun = false;

    //region RobotUtilCallback
    @Override
    public void onEventUserUtterance(JSONObject _jsonObject) {
        RobotUtil.getInstance().robotAPI.robot.setExpression(RobotFace.HIDEFACE);
        try {
            JSONObject jsonObject = _jsonObject.getJSONObject("event_user_utterance");
            JSONArray jA = new JSONArray(jsonObject.getString("user_utterance"));
            JSONArray jsonArray = null;
            String string = "";
            try {
                jsonArray = jA.getJSONObject(0).getJSONArray("result");
            } catch (Exception e) {
                e.printStackTrace();
                string = jA.getJSONObject(0).getString("result");
            }

            if (jsonArray != null) {
                for (int i = 0; i < jsonArray.length(); i++) {
                    Log.d("Survey", "jsonArray1 " + i + " - " + jsonArray.getString(i));
                    String _str = jsonArray.getString(i);

                    if (_str.equals("沒有") || _str.equals("完全沒有") || _str.equals("0分")) {
                        if (isRun) {
                            isRun = false;
                            speakResult(false, 1);
                        }
                        //iAnswer = 1;
                        break;
                    } else if (_str.equals("輕微") || _str.equals("1分")) {
                        if (isRun) {
                            isRun = false;
                            speakResult(false, 2);
                        }
                        //iAnswer = 2;
                        break;
                    } else if (_str.equals("中等") || _str.equals("中等程度") || _str.equals("2分")) {
                        if (isRun) {
                            isRun = false;
                            speakResult(false, 3);
                        }
                        //iAnswer = 3;
                        break;
                    } else if (_str.equals("厲害") || _str.equals("3分")) {
                        if (isRun) {
                            isRun = false;
                            speakResult(false, 4);
                        }
                        //iAnswer = 4;
                        break;
                    } else if (_str.equals("非常") || _str.equals("非常厲害") || _str.equals("4分")) {
                        if (isRun) {
                            isRun = false;
                            speakResult(false, 5);
                            //iAnswer = 5;
                        }
                        break;
                    } else if (_str.equals("Question one") || _str.equals("第一題") || _str.equals("1")) {
                        if (!isRun) {
                            isRun = true;
                            speakResult(true, 1);
                            RobotUtil.getInstance().robotAPI.robot.speakAndListen("感覺緊張不安。1完全沒有2輕微3中等程度4厲害5非常厲害", 5f);
                            //iQuestion =1;
                        }
                        break;
                    } else if (_str.equals("Question two") || _str.equals("第二題") || _str.equals("2")) {
                        if (!isRun) {
                            isRun = true;
                            speakResult(true, 2);
                            RobotUtil.getInstance().robotAPI.robot.speakAndListen("覺得容易苦惱或動怒。1完全沒有2輕微3中等程度4厲害5非常厲害", 5f);
                            //iQuestion =2;
                        }
                        break;
                    } else if (_str.equals("Question three") || _str.equals("第三題") || _str.equals("3")) {
                        if (!isRun) {
                            isRun = true;
                            speakResult(true, 3);
                            RobotUtil.getInstance().robotAPI.robot.speakAndListen("感覺憂鬱、心情低弱。1完全沒有2輕微3中等程度4厲害5非常厲害", 5f);
                            //iQuestion =3;
                        }
                        break;
                    } else if (_str.equals("Question four") || _str.equals("第四題") || _str.equals("4")) {
                        if (!isRun) {
                            isRun = true;
                            speakResult(true, 4);
                            RobotUtil.getInstance().robotAPI.robot.speakAndListen("覺得比不上別人。1完全沒有2輕微3中等程度4厲害5非常厲害", 5f);
                            //iQuestion =4;
                        }
                        break;
                    } else if (_str.equals("Question five") || _str.equals("第五題") || _str.equals("5")) {
                        if (!isRun) {
                            isRun = true;
                            speakResult(true, 5);
                            RobotUtil.getInstance().robotAPI.robot.speakAndListen("睡眠困難、譬如難以入睡、易醒或早睡。1完全沒有2輕微3中等程度4厲害5非常厲害", 5f);
                            //iQuestion =4;
                        }
                        break;
                    } else if (_str.equals("送出問卷") || _str.equals("送出")) {
                        if (!isRun) {
                            isRun = true;
                            showAletDialog();
                        }
                        break;
                    } else if (_str.equals("確定") || _str.equals("確認") || _str.equals("確認資訊") || _str.equals("回到問卷")) {
                        if (isRun) {
//                            isRun = true;
                            if (isFinish) {
                                finish();
                            } else {
                                if (dialog.isShowing()) {
                                    dialog.dismiss();
                                    isRun = false;
                                }
                            }
                        }
                        break;
                    } else if (_str.equals("預約") || _str.equals("預約精神科醫生") || _str.equals("精神科醫師")) {
                        if (!isRun) {
                            isRun = true;
                            Intent it = new Intent();
                            it.setAction(Intent.ACTION_VIEW);
                            it.setData(Uri.parse("tel:000"));
                            startActivity(it);
                            finish();
                        }
                        break;
                    }

                }
            } else {
                String _str = string;
                if (_str.equals("沒有") || _str.equals("完全沒有") || _str.equals("0分")) {
                    if (isRun) {
                        isRun = false;
                        speakResult(false, 1);
                    }
                    //iAnswer = 1;
                } else if (_str.equals("輕微") || _str.equals("1分")) {
                    if (isRun) {
                        isRun = false;
                        speakResult(false, 2);
                    }
                    //iAnswer = 2;
                } else if (_str.equals("中等") || _str.equals("中等程度") || _str.equals("2分")) {
                    if (isRun) {
                        isRun = false;
                        speakResult(false, 3);
                    }
                    //iAnswer = 3;
                } else if (_str.equals("厲害") || _str.equals("3分")) {
                    if (isRun) {
                        isRun = false;
                        speakResult(false, 4);
                    }
                    //iAnswer = 4;
                } else if (_str.equals("非常") || _str.equals("非常厲害") || _str.equals("4分")) {
                    if (isRun) {
                        isRun = false;
                        speakResult(false, 5);
                    }
                    //iAnswer = 5;
                } else if (_str.equals("Question one") || _str.equals("第一題") || _str.equals("1")) {
                    if (!isRun) {
                        isRun = true;
                        speakResult(true, 1);
                        RobotUtil.getInstance().robotAPI.robot.speakAndListen("感覺緊張不安。1完全沒有2輕微3中等程度4厲害5非常厲害", 5f);
                        //iQuestion =1;
                    }
                } else if (_str.equals("Question two") || _str.equals("第二題") || _str.equals("2")) {
                    if (!isRun) {
                        isRun = true;
                        speakResult(true, 2);
                        RobotUtil.getInstance().robotAPI.robot.speakAndListen("覺得容易苦惱或動怒。1完全沒有2輕微3中等程度4厲害5非常厲害", 5f);
                        //iQuestion =2;
                    }
                } else if (_str.equals("Question three") || _str.equals("第三題") || _str.equals("3")) {
                    if (!isRun) {
                        isRun = true;
                        speakResult(true, 3);
                        RobotUtil.getInstance().robotAPI.robot.speakAndListen("感覺憂鬱、心情低弱。1完全沒有2輕微3中等程度4厲害5非常厲害", 5f);
                        //iQuestion =3;
                    }
                } else if (_str.equals("Question four") || _str.equals("第四題") || _str.equals("4")) {
                    if (!isRun) {
                        isRun = true;
                        speakResult(true, 4);
                        RobotUtil.getInstance().robotAPI.robot.speakAndListen("覺得比不上別人。1完全沒有2輕微3中等程度4厲害5非常厲害", 5f);
                        //iQuestion =4;
                    }
                } else if (_str.equals("Question five") || _str.equals("第五題") || _str.equals("5")) {
                    if (!isRun) {
                        isRun = true;
                        speakResult(true, 5);
                        RobotUtil.getInstance().robotAPI.robot.speakAndListen("睡眠困難、譬如難以入睡、易醒或早睡。1完全沒有2輕微3中等程度4厲害5非常厲害", 5f);
                        //iQuestion =4;
                    }
                } else if (_str.equals("送出問卷") || _str.equals("送出")) {
                    if (!isRun) {
                        isRun = true;
                        showAletDialog();
                    }
                } else if (_str.equals("確定") || _str.equals("確認") || _str.equals("確認資訊") || _str.equals("回到問卷")) {
                    if (isRun) {
//                        isRun = true;
                        if (isFinish) {
                            finish();
                        } else {
                            if (dialog.isShowing()) {
                                dialog.dismiss();
                                isRun = false;
                            }
                        }
                    }
                } else if (_str.equals("預約") || _str.equals("預約精神科醫生") || _str.equals("精神科醫師")) {
                    if (!isRun) {
                        isRun = true;
                        Intent it = new Intent();
                        it.setAction(Intent.ACTION_VIEW);
                        it.setData(Uri.parse("tel:000"));
                        startActivity(it);
                        finish();
                    }
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
            Log.d("Survey", "JSONException - " + e.toString());
        }
    }
    //endregion
}





