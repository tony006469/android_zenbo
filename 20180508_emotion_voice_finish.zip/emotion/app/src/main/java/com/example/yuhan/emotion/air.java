package com.example.yuhan.emotion;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.asus.robotframework.API.RobotFace;
import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;
import com.squareup.okhttp.Call;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;


public class air extends AppCompatActivity implements LocationListener, RobotUtilCallback {


    private String TAG = "AIR";

    boolean isRun = false;

    @Override
    public void onEventUserUtterance(JSONObject _jsonObject) {
        RobotUtil.getInstance().robotAPI.robot.setExpression(RobotFace.HIDEFACE);
        try {
            JSONObject jsonObject = _jsonObject.getJSONObject("event_user_utterance");
            JSONArray jA = new JSONArray(jsonObject.getString("user_utterance"));
            JSONArray jsonArray = null;
            String string = "";
            try {
                jsonArray = jA.getJSONObject(0).getJSONArray("result");
            } catch (Exception e) {
                e.printStackTrace();
                string = jA.getJSONObject(0).getString("result");
            }

            if (jsonArray != null) {
                for (int i = 0; i < jsonArray.length(); i++) {
                    Log.d("MainActivity", "jsonArray1 " + i + " - " + jsonArray.getString(i));
                    String _str = jsonArray.getString(i);

                    if (_str.equals("bye bye") || _str.equals("再見") || _str.equals("拜拜") || _str.equals("See you")) {
                        if (!isRun) {
                            isRun = true;
                            finish();
                        }
                        break;
                    }
                }
            } else {
                String _str = string;
                if (_str.equals("bye bye") || _str.equals("再見") || _str.equals("拜拜") || _str.equals("See you")) {
                    if (!isRun) {
                        isRun = true;
                        finish();
                    }
                }
            }

        } catch (JSONException e) {
            e.printStackTrace();
            Log.d("MainActivity", "JSONException - " + e.toString());
        }


    }

    class Data {

        String SiteName;
        String County;
        String AQI;
        @SerializedName("PM2.5_AVG")
        String PM25_AVG;
        String WindSpeed;

    }

    LocationManager locationManager;
    String bestProv;

    Location location; // location

    double latitude = 25.0142205; // latitude
    double longitude = 121.530066; // longitude

    String[][] trans_array = new String[76][4];
    int i_site = 0;
    float[] allDistance = new float[76];

    ImageView smile;
    ImageView cry;
    ImageView normal;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.air);

        RobotUtil.getInstance().defaultValue(this, this);

        // 檢查授權
        requestPermission();
        AirSite();
        mMain();
        //RightNowLocation();
        cntDist();
    }


    // 檢查授權
    private void requestPermission() {
        if (Build.VERSION.SDK_INT >= 23) {  // Android 6.0 以上
            // 判斷是否已取得授權
            int hasPermission = ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION);
            if (hasPermission != PackageManager.PERMISSION_GRANTED) {  // 未取得授權
                ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 1);
                return;
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == 1) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "歡迎使用", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "未取得授權！", Toast.LENGTH_SHORT).show();
                finish();
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }


    @Override
    public void onLocationChanged(Location location) {
        TextView mysite;
        String x = "緯=" + Double.toString(location.getLatitude());
        String y = "經=" + Double.toString(location.getLongitude());
        Toast.makeText(this, x + "\n" + y, Toast.LENGTH_LONG).show();
        this.location = location;
        this.latitude = location.getLatitude();
        this.longitude = location.getLongitude();
        cntDist();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 取得定位服務
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        // 取得最佳定位
        Criteria criteria = new Criteria();
        bestProv = locationManager.getBestProvider(criteria, true);

        RobotUtil.getInstance().Resume();
        RobotUtil.getInstance().defaultValue(this, this);
        isRun = false;

        // 如果GPS或網路定位開啟，更新位置
        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
            //  確認 ACCESS_FINE_LOCATION 權限是否授權
            if (ActivityCompat.checkSelfPermission(this,
                    android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                locationManager.requestLocationUpdates(bestProv, 1000, 1, this);
            }
        } else {
            Toast.makeText(this, "請開啟定位服務", Toast.LENGTH_LONG).show();
        }
        RightNowLocation();
    }

    @Override
    protected void onPause() {
        super.onPause();
        //  確認 ACCESS_FINE_LOCATION 權限是否授權
        if (ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            locationManager.removeUpdates(this);
        }
    }


    @Override
    public void onProviderDisabled(String provider) {
        Toast.makeText(air.this, "Please Enable GPS and Internet", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        Criteria criteria = new Criteria();
        bestProv = locationManager.getBestProvider(criteria, true);
    }

    @Override
    public void onProviderEnabled(String provider) {

    }


    String text;

    public void mMain() {
        //切換Layout
        LayoutInflater mInflater = getLayoutInflater();
        final View view_main = mInflater.inflate(R.layout.air, null);
        setContentView(view_main);

        final TextView mytext;
        final Button button_north;
        final Button button_yilan;
        final Button button_chumiao;
        final Button button_central;
        final Button button_yungianan;
        final Button button_kaopin;
        final Button button_east;
        final Button button_outer;
        final Button button_check;
        final Button button_current;
        final Button button_next;
        final String[] list_item = new String[1];
        final String[] gps_item = new String[1];

        final ImageView smile;
        final ImageView cry;
        final ImageView normal;

        /**Face Image**/
        smile = (ImageView) findViewById(R.id.imageView2);
        normal = (ImageView) findViewById(R.id.imageView4);
        cry = (ImageView) findViewById(R.id.imageView3);


        //北區
        button_north = (Button) findViewById(R.id.button1);
        button_north.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Spinner spinner = (Spinner) findViewById(R.id.spnPrefer);
                final String[] lunch = {"基隆", "汐止", "萬里", "新店", "土城", "板橋", "新莊", "菜寮",
                        "林口", "淡水", "士林", "中山", "萬華", "古亭", "松山", "大同", "桃園", "大園", "觀音",
                        "平鎮", "龍潭", "陽明", "三重", "中壢", "永和"};
                ArrayAdapter<String> lunchList = new ArrayAdapter<>(air.this,
                        android.R.layout.simple_spinner_dropdown_item,
                        lunch);
                spinner.setAdapter(lunchList);
                //   text = spinner.getSelectedItem().toString();
            }
        });
        button_yilan = (Button) findViewById(R.id.button2);
        button_yilan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Spinner spinner = (Spinner) findViewById(R.id.spnPrefer);
                final String[] lunch = {"宜蘭", "冬山"};
                ArrayAdapter<String> lunchList = new ArrayAdapter<>(air.this,
                        android.R.layout.simple_spinner_dropdown_item,
                        lunch);
                spinner.setAdapter(lunchList);
                //   text = spinner.getSelectedItem().toString();
            }
        });
        button_chumiao = (Button) findViewById(R.id.button3);
        button_chumiao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Spinner spinner = (Spinner) findViewById(R.id.spnPrefer);
                final String[] lunch = {"湖口", "竹東", "新竹", "頭份", "苗栗", "三義"};
                ArrayAdapter<String> lunchList = new ArrayAdapter<>(air.this,
                        android.R.layout.simple_spinner_dropdown_item,
                        lunch);
                spinner.setAdapter(lunchList);
                //  text = spinner.getSelectedItem().toString();
            }
        });
        button_central = (Button) findViewById(R.id.button4);
        button_central.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Spinner spinner = (Spinner) findViewById(R.id.spnPrefer);
                final String[] lunch = {"豐原", "沙鹿", "大里", "忠明", "西屯", "彰化", "線西", "二林",
                        "南投", "竹山", "埔里"};
                ArrayAdapter<String> lunchList = new ArrayAdapter<>(air.this,
                        android.R.layout.simple_spinner_dropdown_item,
                        lunch);
                spinner.setAdapter(lunchList);
                //    text = spinner.getSelectedItem().toString();
            }
        });
        button_yungianan = (Button) findViewById(R.id.button5);
        button_yungianan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Spinner spinner = (Spinner) findViewById(R.id.spnPrefer);
                final String[] lunch = {"斗六", "崙背", "新港", "朴子", "臺西", "嘉義", "新營", "善化",
                        "安南", "臺南", "麥寮"};
                ArrayAdapter<String> lunchList = new ArrayAdapter<>(air.this,
                        android.R.layout.simple_spinner_dropdown_item,
                        lunch);
                spinner.setAdapter(lunchList);
                //  text = spinner.getSelectedItem().toString();
            }
        });
        button_kaopin = (Button) findViewById(R.id.button6);
        button_kaopin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Spinner spinner = (Spinner) findViewById(R.id.spnPrefer);
                final String[] lunch = {"美濃", "橋頭", "仁武", "鳳山", "大寮", "林園", "楠梓", "左營",
                        "前金", "前鎮", "小港", "屏東", "潮州", "恆春", "復興"};
                ArrayAdapter<String> lunchList = new ArrayAdapter<>(air.this,
                        android.R.layout.simple_spinner_dropdown_item,
                        lunch);
                spinner.setAdapter(lunchList);
                //   text = spinner.getSelectedItem().toString();
            }
        });
        button_east = (Button) findViewById(R.id.button7);
        button_east.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Spinner spinner = (Spinner) findViewById(R.id.spnPrefer);
                final String[] lunch = {"臺東", "花蓮", "關山"};
                ArrayAdapter<String> lunchList = new ArrayAdapter<>(air.this,
                        android.R.layout.simple_spinner_dropdown_item,
                        lunch);
                spinner.setAdapter(lunchList);
                //   text = spinner.getSelectedItem().toString();
            }
        });
        button_outer = (Button) findViewById(R.id.button8);
        button_outer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Spinner spinner = (Spinner) findViewById(R.id.spnPrefer);
                final String[] lunch = {"馬祖", "金門", "馬公"};
                ArrayAdapter<String> lunchList = new ArrayAdapter<>(air.this,
                        android.R.layout.simple_spinner_dropdown_item,
                        lunch);
                spinner.setAdapter(lunchList);
                // text = spinner.getSelectedItem().toString();

            }
        });


        Spinner spinner = (Spinner) findViewById(R.id.spnPrefer);
        spinner.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                // TODO Auto-generated method stub
                String spStr = String.valueOf(adapterView.getSelectedItem());  //取得選取的ID ; 若要取得選取的文字,可改用getSelectedItem()
                text = spStr.toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub

            }

        });

        mytext = (TextView) findViewById(R.id.textView1);
        button_check = (Button) findViewById(R.id.check);
        button_check.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                smile.setVisibility(View.INVISIBLE);
                normal.setVisibility(View.INVISIBLE);
                cry.setVisibility(View.INVISIBLE);

                OkHttpClient mOkHttpClient = new OkHttpClient();
                Request request = new Request.Builder()
                        .url("http://opendata.epa.gov.tw/ws/Data/AQI/?%24orderby=SiteName&%24skip=0&%24top=1000&format=json")
                        .build();

                Call call = mOkHttpClient.newCall(request);

                call.enqueue(new Callback() {
                    @Override
                    public void onFailure(Request request, IOException e) {
                    }

                    @Override
                    public void onResponse(final Response response) throws IOException {
                        Intent i = new Intent("MyMessage");
                        i.putExtra("json", response.body().string());
                        Log.d(TAG, "btn check onResponse - " + response.body().string());
                        sendBroadcast(i);
                    }
                });
            }
        });

        BroadcastReceiver myBroadcasReceiver = new BroadcastReceiver() {

            @Override
            public void onReceive(Context context, Intent intent) {
                String myJson = intent.getExtras().getString("json");
                Log.d(TAG, "MyMessage onReceive - " + myJson);

                Gson gson = new Gson();
                air.Data[] data = gson.fromJson(myJson, air.Data[].class);

                for (int i = 0; i < 1; i++) {
                    list_item[i] = new String();
                }

                int NumAQI;
//                        , theSite;
//                theSite = 0;
//
//                for (int i = 0; i < data.length; i++) {
//                    if (data[i].SiteName.toString().equals(trans_array[i_site][0])) {
//                        theSite = i;
//                        break;
//                    }
//                }

                for (int i = 0; i < data.length; i++) {
                    if (data[i].SiteName.toString().equals(text)) {
                        RightNowSpeak(intent, i);
                        if (data[i].AQI.toString().equals("") | data[i].PM25_AVG.toString().equals("")) {
                            list_item[0] += "設備維護";
                            break;
                        }
                        list_item[0] += "\n查詢測站位置：" + data[i].SiteName;
                        list_item[0] += "\nWind Speed：" + data[i].WindSpeed + " m/s";
                        list_item[0] += "\nPM2.5：" + data[i].PM25_AVG + " μg/m3";
                        list_item[0] += "\nAQI：" + data[i].AQI + "\n";


                        NumAQI = Integer.parseInt(data[i].AQI.toString());
                        if (NumAQI <= 50) {
                            list_item[0] += "\nAQI健康影響：良好。\n" +
                                    "一般民眾活動建議：正常戶外活動。\n" +
                                    "敏感族群活動建議：正常戶外活動。\n";
                            smile.setVisibility(View.VISIBLE);
                        } else if (NumAQI > 50 && NumAQI <= 100) {
                            list_item[0] += "\nAQI健康影響：普通。\n" +
                                    "一般民眾活動建議：正常戶外活動。\n" +
                                    "敏感族群活動建議：極特殊敏感族群建議注意可能產生的咳嗽或呼吸急促症狀，但仍可正常戶外活動。\n";
                            normal.setVisibility(View.VISIBLE);
                        } else if (NumAQI > 100 && NumAQI <= 150) {
                            list_item[0] += "\nAQI健康影響：對敏感族群的健康造成影響。\n" +
                                    "一般民眾活動建議：1.一般民眾如果有不適，如眼痛，咳嗽或喉嚨痛等，應該考慮減少戶外活動。2.學生仍可進行戶外活動，但建議減少長時間劇烈運動。\n" +
                                    "敏感族群活動建議：1.有心臟、呼吸道及心血管疾病患者、孩童及老年人，建議減少體力消耗活動及戶外活動，必要外出應配戴口罩。2.具有氣喘的人可能需增加使用吸入劑的頻率。\n";
                            normal.setVisibility(View.VISIBLE);
                        } else if (NumAQI > 150 && NumAQI <= 200) {
                            list_item[0] += "\nAQI健康影響：對所有人的健康造成影響。\n" +
                                    "一般民眾活動建議：1.一般民眾如果有不適，如眼痛，咳嗽或喉嚨痛等，應減少體力消耗，特別是減少戶外活動。2.學生應避免長時間劇烈運動，進行其他戶外活動時應增加休息時間。\n" +
                                    "敏感族群活動建議：1.有心臟、呼吸道及心血管疾病患者、孩童及老年人，建議留在室內並減少體力消耗活動，必要外出應配戴口罩。2.具有氣喘的人可能需增加使用吸入劑的頻率。\n";
                            cry.setVisibility(View.VISIBLE);
                        } else if (NumAQI > 200 && NumAQI <= 300) {
                            list_item[0] += "\nAQI健康影響：非常不健康。\n" +
                                    "一般民眾活動建議：1.一般民眾應減少戶外活動。2.學生應立即停止戶外活動，並將課程調整於室內進行。\n" +
                                    "敏感族群活動建議：1.有心臟、呼吸道及心血管疾病患者、孩童及老年人應留在室內並減少體力消耗活動，必要外出應配戴口罩。2.具有氣喘的人應增加使用吸入劑的頻率。\n";
                            cry.setVisibility(View.VISIBLE);
                        } else {
                            list_item[0] += "\nAQI健康影響：危害。\n" +
                                    "一般民眾活動建議：1.一般民眾應避免戶外活動，室內應緊閉門窗，必要外出應配戴口罩等防護用具。2.學生應立即停止戶外活動，並將課程調整於室內進行。\n" +
                                    "敏感族群活動建議：1.有心臟、呼吸道及心血管疾病患者、孩童及老年人應留在室內並避免體力消耗活動，必要外出應配戴口罩。2.具有氣喘的人應增加使用吸入劑的頻率。\n";
                            cry.setVisibility(View.VISIBLE);
                        }
                    }
                }

                mytext.setText(list_item[0]);
            }
        };
        IntentFilter intentFilter = new IntentFilter("MyMessage");
        registerReceiver(myBroadcasReceiver, intentFilter);


        /**目前位置**/
        button_current = (Button) findViewById(R.id.current);
        button_current.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RightNowLocation();
            }
        });

        BroadcastReceiver myBroadcasReceiver2 = new BroadcastReceiver() {

            @Override
            public void onReceive(Context context, Intent intent) {
                int theSite = i_site;
                RightNowSpeak(intent, theSite);
                String myJson = intent.getExtras().getString("json");
                Log.d(TAG, "HereAQI onReceive - " + myJson);
                Gson gson = new Gson();
                air.Data[] data = gson.fromJson(myJson, air.Data[].class);

                for (int i = 0; i < 1; i++) {
                    gps_item[i] = new String();
                }

                int NumAQI_gps;

                gps_item[0] += "\n最近測站位置：" + trans_array[theSite][0] + ", " + trans_array[theSite][1];
                gps_item[0] += "\nWind Speed：" + data[theSite].WindSpeed + " m/s";
                gps_item[0] += "\nPM2.5：" + data[theSite].PM25_AVG + " μg/m3";
                gps_item[0] += "\nAQI：" + data[theSite].AQI + "\n";

                /**目前位置的AQI判斷**/
                if (data[theSite].AQI.toString().equals("")) {
                    gps_item[0] = "設備維護";
                } else {
                    NumAQI_gps = Integer.parseInt(data[theSite].AQI.toString());
                    if (NumAQI_gps <= 50) {
                        gps_item[0] += "\nAQI健康影響：良好。\n" +
                                "一般民眾活動建議：正常戶外活動。\n" +
                                "敏感族群活動建議：正常戶外活動。\n";
                        smile.setVisibility(View.VISIBLE);
                    } else if (NumAQI_gps > 50 && NumAQI_gps <= 100) {
                        gps_item[0] += "\nAQI健康影響：普通。\n" +
                                "一般民眾活動建議：正常戶外活動。\n" +
                                "敏感族群活動建議：極特殊敏感族群建議注意可能產生的咳嗽或呼吸急促症狀，但仍可正常戶外活動。\n";
                        normal.setVisibility(View.VISIBLE);

                    } else if (NumAQI_gps > 100 && NumAQI_gps <= 150) {
                        gps_item[0] += "\nAQI健康影響：對敏感族群的健康造成影響。\n" +
                                "一般民眾活動建議：1.一般民眾如果有不適，如眼痛，咳嗽或喉嚨痛等，應該考慮減少戶外活動。2.學生仍可進行戶外活動，但建議減少長時間劇烈運動。\n" +
                                "敏感族群活動建議：1.有心臟、呼吸道及心血管疾病患者、孩童及老年人，建議減少體力消耗活動及戶外活動，必要外出應配戴口罩。2.具有氣喘的人可能需增加使用吸入劑的頻率。\n";
                        normal.setVisibility(View.VISIBLE);
                    } else if (NumAQI_gps > 150 && NumAQI_gps <= 200) {
                        gps_item[0] += "\nAQI健康影響：對所有人的健康造成影響。\n" +
                                "一般民眾活動建議：1.一般民眾如果有不適，如眼痛，咳嗽或喉嚨痛等，應減少體力消耗，特別是減少戶外活動。2.學生應避免長時間劇烈運動，進行其他戶外活動時應增加休息時間。\n" +
                                "敏感族群活動建議：1.有心臟、呼吸道及心血管疾病患者、孩童及老年人，建議留在室內並減少體力消耗活動，必要外出應配戴口罩。2.具有氣喘的人可能需增加使用吸入劑的頻率。\n";
                        cry.setVisibility(View.VISIBLE);
                    } else if (NumAQI_gps > 200 && NumAQI_gps <= 300) {
                        gps_item[0] += "\nAQI健康影響：非常不健康。\n" +
                                "一般民眾活動建議：1.一般民眾應減少戶外活動。2.學生應立即停止戶外活動，並將課程調整於室內進行。\n" +
                                "敏感族群活動建議：1.有心臟、呼吸道及心血管疾病患者、孩童及老年人應留在室內並減少體力消耗活動，必要外出應配戴口罩。2.具有氣喘的人應增加使用吸入劑的頻率。\n";
                        cry.setVisibility(View.VISIBLE);
                    } else {
                        gps_item[0] += "\nAQI健康影響：危害。\n" +
                                "一般民眾活動建議：1.一般民眾應避免戶外活動，室內應緊閉門窗，必要外出應配戴口罩等防護用具。2.學生應立即停止戶外活動，並將課程調整於室內進行。\n" +
                                "敏感族群活動建議：1.有心臟、呼吸道及心血管疾病患者、孩童及老年人應留在室內並避免體力消耗活動，必要外出應配戴口罩。2.具有氣喘的人應增加使用吸入劑的頻率。\n";
                        cry.setVisibility(View.VISIBLE);
                    }
                }
                Log.d(TAG, "gps_item - " + gps_item[0]);

                mytext.setText(gps_item[0]);
            }
        };
        IntentFilter intentFilter2 = new IntentFilter("HereAQI");
        registerReceiver(myBroadcasReceiver2, intentFilter2);

//        /***室內舒適度***/
//        button_indoor = (Button)findViewById(R.id.indoor);
//        button_indoor.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Spinner spinner = (Spinner)findViewById(R.id.spnPrefer);
//                final String[] lunch = {"室內"};
//                ArrayAdapter<String> lunchList = new ArrayAdapter<>(air.this,
//                        android.R.layout.simple_spinner_dropdown_item,
//                        lunch);
//                spinner.setAdapter(lunchList);
//                smile.setVisibility(View.INVISIBLE);
//                normal.setVisibility(View.INVISIBLE);
//                cry.setVisibility(View.INVISIBLE);
//
//                mytext.setText("室內溫度:Null\n" +
//                        "建議開啟冷氣/暖氣\n" +
//                        "\n" +
//                        "室內濕度:Null\n" +
//                        "建議開啟除濕機\n" +
//                        "\n" +
//                        "室內空氣:Null\n" +
//                        "建議開啟空氣清淨機\n");
//
//            }
//        });

    }


    //講出目前位置的AQI
    public void RightNowSpeak(Intent intent, int theSite) {

        String myJson = intent.getExtras().getString("json");
        Log.d(TAG, "RightNowSpeak - " + myJson);
        Gson gson = new Gson();
        air.Data[] data = gson.fromJson(myJson, air.Data[].class);

        int NumAQI_gps;

        if (data[theSite].AQI.toString().equals("")) {
            RobotUtil.getInstance().robotAPI.robot.speak("設備維護");
        } else {
            NumAQI_gps = Integer.parseInt(data[theSite].AQI.toString());

            if (NumAQI_gps <= 100) {
                RobotUtil.getInstance().robotAPI.robot.speak("哇！今日空氣品質指標為" + NumAQI_gps + "空氣品質超好的！建議您出外走動活動一下筋骨！");
            } else if (NumAQI_gps > 101) {
                RobotUtil.getInstance().robotAPI.robot.speak("天呀！今日空氣品質指標為" + NumAQI_gps + "空氣品質實在太差了！建議您在家休息不要出外走動，可以聽聽音樂，做做運動。");
            }
        }
    }


    //目前位置
    public void RightNowLocation() {

        Spinner spinner = (Spinner) findViewById(R.id.spnPrefer);
        final String[] lunch = {"現在位置"};
        ArrayAdapter<String> lunchList = new ArrayAdapter<>(air.this,
                android.R.layout.simple_spinner_dropdown_item,
                lunch);
        spinner.setAdapter(lunchList);

        /**Face Image**/
        smile = (ImageView) findViewById(R.id.imageView2);
        normal = (ImageView) findViewById(R.id.imageView4);
        cry = (ImageView) findViewById(R.id.imageView3);

        smile.setVisibility(View.INVISIBLE);
        normal.setVisibility(View.INVISIBLE);
        cry.setVisibility(View.INVISIBLE);

        OkHttpClient mOkHttpClient = new OkHttpClient();

        Request request = new Request.Builder()
                .url("http://opendata.epa.gov.tw/ws/Data/AQI/?%24orderby=SiteName&%24skip=0&%24top=1000&format=json")
                .build();

        Call call = mOkHttpClient.newCall(request);

        call.enqueue(new Callback() {
            @Override
            public void onFailure(Request request, IOException e) {
            }

            @Override
            public void onResponse(final Response response) throws IOException {
                Intent i = new Intent("HereAQI");
                i.putExtra("json", response.body().string());
                sendBroadcast(i);
            }
        });
    }


    /**
     * --------切割測站位置--------
     **/
    public void AirSite() {
        String site = "二林,彰化縣,120.409653,23.925175000700026,三重,新北市,121.493806,25.072611000724766,三義,苗栗縣,120.758833,24.382942000710031,土城,新北市,121.451861,24.982528000722873,士林,臺北市,121.515389,25.10541700072546,大同,臺北市,121.513311,25.063200000724578,大里,臺中市,120.677689,24.099611000703863,大園,桃園市,121.201811,25.060344000724509,大寮,高雄市,120.425081,22.565747000669244,小港,高雄市,120.337736,22.565833000669233,中山,臺北市,121.526528,25.062361000724557,中壢,桃園市,121.221667,24.953278000722257,仁武,高雄市,120.332631,22.6890560006721,斗六,雲林縣,120.544994,23.711853000695292,冬山,宜蘭縣,121.792928,24.63220300071541,古亭,臺北市,121.529556,25.020608000723669,左營,高雄市,120.292917,22.674861000671765,平鎮,桃園市,121.203986,24.952786000722238,永和,新北市,121.516306,25.017000000723598,安南,臺南市,120.2175,23.048197000680332,朴子,嘉義縣,120.24735,23.465308000689781,汐止,新北市,121.6423,25.067131000724654,竹山,南投縣,120.677306,23.756389000696291,竹東,新竹縣,121.088903,24.740644000717722,西屯,臺中市,120.616917,24.162197000705234,沙鹿,臺中市,120.568794,24.22562800070661,宜蘭,宜蘭縣,121.746394,24.74791700071788,忠明,臺中市,120.641092,24.151958000704997,松山,臺北市,121.578611,25.0500000007243,板橋,新北市,121.458667,25.012972000723511,林口,新北市,121.376869,25.077197000724865,林園,高雄市,120.41175,22.479500000667237,花蓮,花蓮縣,121.599769,23.971306000701038,金門,金門縣,118.31225599998685,24.43213300070606,前金,高雄市,120.288086,22.632567000670793,前鎮,高雄市,120.307564,22.605386000670162,南投,南投縣,120.685306,23.913000000699753,屏東,屏東縣,120.488033,22.673081000671722,恆春,屏東縣,120.788928,21.95806900065498,美濃,高雄市,120.530542,22.88358300067658,苗栗,苗栗縣,120.8202,24.565269000713961,埔里,南投縣,120.967903,23.968842000700981,桃園,桃園市,121.319964,24.994789000723134,馬公,澎湖縣,119.56615799999966,23.569031000692004,馬祖,連江縣,119.949875,26.160469000747128,基隆,基隆市,121.760056,25.129167000725957,崙背,雲林縣,120.348742,23.757547000696309,淡水,新北市,121.449239,25.164500000726708,麥寮,雲林縣,120.251825,23.753506000696216,善化,臺南市,120.297142,23.115097000681867,復興,高雄市,120.312017,22.608711000670233,湖口,新竹縣,121.038653,24.900142000721125,菜寮,新北市,121.481028,25.068950000724694,陽明,臺北市,121.529583,25.182722000727075,新竹,新竹市,120.972075,24.805619000719119,新店,新北市,121.537778,24.977222000722765,新莊,新北市,121.4325,25.037972000724039,新港,嘉義縣,120.345531,23.554839000691793,新營,臺南市,120.31725,23.305633000686182,楠梓,高雄市,120.328289,22.733667000673119,萬里,新北市,121.689881,25.179667000727022,萬華,臺北市,121.507972,25.046503000724222,嘉義,嘉義市,120.440833,23.46277800068972,彰化,彰化縣,120.541519,24.066000000703117,臺西,雲林縣,120.202842,23.717533000695422,臺東,臺東縣,121.15045,22.755358000673624,臺南,臺南市,120.202617,22.98458100067888,鳳山,高雄市,120.358083,22.627392000670667,潮州,屏東縣,120.561175,22.523108000668241,線西,彰化縣,120.469061,24.131672000704558,橋頭,高雄市,120.305689,22.757506000673683,頭份,苗栗縣,120.898572,24.696969000716795,龍潭,桃園市,121.21635,24.863869000720356,豐原,臺中市,120.741711,24.256586000707298,關山,臺東縣,121.161933,23.045083000680275,觀音,桃園市,121.082761,25.035503000723981";

        String[] tokens = site.split(",");
        ArrayList myList = new ArrayList();
        int len = tokens.length;

        for (int i = 0; i < len; i++) {
            myList.add(tokens[i]);
        }
        //int k = myList.size()/4;
        int count = 0;
        //String[][] trans_array = new String[k][4];
        for (int x = 0; x < myList.size() / 4; x++) {
            for (int y = 0; y < 4; y++) {
                trans_array[x][y] = (String) myList.get(count);
                count++; //一個index來決定myList讀取值的位置
            }
        }
    }

    /**
     * 計算距離最近的測站
     **/
    public void cntDist() {
        //int i_site = 0;
        Log.d(TAG, "latitude/longitude - " + String.valueOf(latitude) + "/" + String.valueOf(longitude));
        float[] cntDistance = new float[3];

        float minDistance;

        for (int i = 0; i < 76; i++) {
            Location.distanceBetween(latitude, longitude, Double.parseDouble(trans_array[i][3]), Double.parseDouble(trans_array[i][2]), cntDistance);
            allDistance[i] = cntDistance[0];
        }

        minDistance = allDistance[0];
        for (int i = 0; i < 76; i++) {
            if (minDistance > allDistance[i]) {
                minDistance = allDistance[i];
                i_site = i;
            }
        }
        Log.d(TAG, "cntDist - " + trans_array[i_site][0] + "/" + trans_array[i_site][1]);

    }

}
